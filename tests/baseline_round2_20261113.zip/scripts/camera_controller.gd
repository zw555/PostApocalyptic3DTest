extends Camera3D
@export var target_path: NodePath
@export var follow_speed := 7.0
@export var view_size := 13.8
@export var target_offset := Vector3(0, 0.75, -2.3)
var mode := 2
var elevation := 65.0
var focus := Vector3.ZERO
var initialized := false
var follow_enabled := true

func _ready() -> void:
	projection = Camera3D.PROJECTION_ORTHOGONAL
	keep_aspect = Camera3D.KEEP_HEIGHT
	size = view_size
	current = true
	reset_follow()

func set_mode(value: int) -> void:
	mode = clampi(value, 1, 2)
	elevation = 85.0 if mode == 1 else 65.0
	# Same target, camera distance, and orthographic size in both modes.
	apply_pose()

func reset_follow() -> void:
	var target := get_node_or_null(target_path) as Node3D
	if target:
		focus = target.global_position + target_offset
	initialized = true
	apply_pose()

func apply_pose() -> void:
	var angle := deg_to_rad(elevation)
	global_position = focus + Vector3(0, sin(angle), cos(angle)) * 22.0
	look_at(focus, Vector3.UP)

func _process(delta: float) -> void:
	if not follow_enabled:
		return
	var target := get_node_or_null(target_path) as Node3D
	if target:
		var desired := target.global_position + target_offset
		focus = focus.lerp(desired, 1.0 - exp(-follow_speed * delta)) if initialized else desired
		initialized = true
		apply_pose()
