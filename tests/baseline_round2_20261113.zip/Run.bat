@echo off
setlocal
set "GODOT_BIN=E:\Godot_v4.5.2-stable_win64.exe\Godot_v4.5.2-stable_win64.exe"
if exist "%GODOT_BIN%" (
    start "After Hours 3D Validation" "%GODOT_BIN%" --path "%~dp0."
    exit /b
)
where godot >nul 2>nul
if not errorlevel 1 (
    start "After Hours 3D Validation" godot --path "%~dp0."
    exit /b
)
echo Godot 4.5.2 not found. Import project.godot in your installed Godot editor.
pause
