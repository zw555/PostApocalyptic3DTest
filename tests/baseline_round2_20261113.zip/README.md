# AFTER HOURS — Godot 4.5.2 独立 3D 美术验证

12m × 10m 废弃便利店，原生 Mesh、GDScript、GodotPhysics3D。无插件、下载模型、外部素材或 Blender 运行依赖。此项目位于 `E:\GameProject\PostApocalyptic3DTest`，与现有游戏目录并列。

## 开始运行

本机直接双击 `Run.bat`。或在 Godot **4.5.2** 项目管理器导入本目录的 `project.godot`，按 F6 运行 `scenes/main.tscn`，或按 F5 运行项目。默认采用 Forward+ / Vulkan；本机已用 RTX 4060 Laptop GPU 运行并截图。

项目交付的是完整 Godot 源工程，不是导出的独立 EXE。`Run.bat` 优先查找本机已安装的 Godot 路径，移动到其他电脑后可通过 Godot 编辑器直接打开。

| 操作 | 功能 |
| --- | --- |
| WASD | 沿相机水平投影方向移动，斜向归一化 |
| F1 | 正交 85° 俯视 |
| F2 | 正交 65° 斜俯视，默认模式 |
| F3 | 开关两盏局部灯光 |
| F4 | 开关全部三盏光源的动态阴影 |
| R | 返回出生点，重置平滑相机位置 |

角度相对水平地面。两种模式保持相同目标点和 13.8m 正交视野高度。为完整观察店内，跟随目标有固定偏移 `(0, 0.75, -2.3)`；没有自由旋转或透视缩放。85° 下竖直人体会自然缩短为接近头顶的轮廓，这属于真实投影变化。

门洞在东侧 `X=6, Z=2.8`，净宽 1.2m。墙体与货架是真实静态碰撞体。门外只有一小块验证平台，使用 R 可随时返回；本轮没有室外地图。

## 在编辑器中搭建

- 打开 `scenes/environment/convenience_store.tscn`，移动或复制 `Furniture` 下的独立 PackedScene 实例即可搭建。
- `shelf.tscn` 是 2.4m 货架；`shelf_long.tscn` 是 3.2m 货架。地面均为 Y=0，家具原点在底部，不需要逐个猜测高度。
- 选中货架根节点，在 Inspector 调整 `shelf_width / shelf_depth / shelf_height / shelf_levels / product_seed / stock_density`。`@tool` 脚本会重建自己的 `Geometry`，不修改兄弟节点。参数在实例中覆盖后，重新加载时也会校验并重建。
- 尺寸范围：宽 0.8–5m，深 0.45–1.4m，高 1–2.8m，2–6 层。层间距较小时商品自动等比缩小以免穿层；正式美术建议使用 1.8m / 4 层附近的比例。
- 不要手工修改货架的 `Geometry` 后又修改生成参数：重新生成会替换该子树。特殊手工资产应复制为独立场景并移除生成脚本。
- `modular_wall.tscn` 及 `wall_*` 是完整可编辑墙模块，可调整长度、高度、厚度和 `cutaway`。南墙、东墙启用固定淡化，保留完整墙体、踢脚线、碰撞和专用不透明阴影代理。不是运行时按遮挡自动淡出的系统。
- 共享材质全部位于 `materials/`。`surface.gdshader` 使用世界坐标噪声、低对比瓷砖缝和木纹。每类材质只保存一份 `.tres`，不为每个商品创建独立材质。
- 冰柜有简化透明展示面和顶面，以便俯视检查内部商品；没有折射、真实玻璃厚度和镜面反射。

## 重建场景

现有 `.tscn` 已烘焙，不需要先运行生成器。所有资源引用均使用 `res://`。

若修改程序化搭建规则，可在 PowerShell 运行：

```powershell
$godot = 'E:\Godot_v4.5.2-stable_win64.exe\Godot_v4.5.2-stable_win64_console.exe'
& $godot --headless --path 'E:\GameProject\PostApocalyptic3DTest' --script res://scripts/procedural/environment_builder.gd
```

生成器会**重写本项目的场景和共享材质**。在编辑器中手工调整布局后，应直接保存场景，避免再次烘焙覆盖调整。需要长期维护的程序化布局可修改 `environment_builder.gd` 中的 `build_store()`。

## 自动验证与截图

```powershell
# 导入、逐个脚本语法、主场景加载、42 项技术检查
& 'E:\GameProject\PostApocalyptic3DTest\tests\run_tests.ps1'

# 同时启动原生图形窗口，生成 7 张真实截图并检查渲染像素变化
& 'E:\GameProject\PostApocalyptic3DTest\tests\run_tests.ps1' -Capture

# 自定义已安装的 Godot 路径
& '.\tests\run_tests.ps1' -GodotPath 'D:\Tools\Godot4.5.2.exe' -Capture
```

测试无需 Python 或 Blender。截图使用运行场景的 Godot Viewport 保存 PNG，不使用 AI 图片，也不把截图作为场景背景。图形截图需要可用的显示器和 GPU；纯 headless 模式无法生成有效画面。`screenshots/.gdignore` 避免将验证图片导入为游戏资产。

结果见 `tests/results/test_run_summary.json`、`validation.json`、`render_validation.json` 和相应 `.log`。短时渲染监视器数据见 `render_metrics.json`，其中 FPS 包含采样窗口影响，不代表持续性能基准。

| 截图 | 用途 |
| --- | --- |
| [01_ortho_85.png](screenshots/01_ortho_85.png) | 85° 俯视 |
| [02_ortho_65.png](screenshots/02_ortho_65.png) | 65° 斜俯视 |
| [03_lights_shadows_on.png](screenshots/03_lights_shadows_on.png) | 局部光与动态阴影开启 |
| [04_dynamic_shadows_off.png](screenshots/04_dynamic_shadows_off.png) | 同机位关闭动态阴影 |
| [05_local_lights_off.png](screenshots/05_local_lights_off.png) | 同机位关闭局部灯光 |
| [06_occlusion_behind_shelf.png](screenshots/06_occlusion_behind_shelf.png) | 人物在货架后方 |
| [07_occlusion_in_front.png](screenshots/07_occlusion_in_front.png) | 人物在货架前方 |

场景、材质、输入和相机代码均为本轮原生生成。技术结论、视觉边界和后续资产建议见 [3D_VALIDATION_REPORT.md](3D_VALIDATION_REPORT.md)。
